import javax.swing.*;
import java.awt.*;;
import java.util.LinkedList;
import java.util.Queue;

public class producer implements Runnable{
    public Buffer buf;
    int count;
    int large_prime;
    public int N;
    public int Buffer ;
    public Queue<String> queue = new LinkedList<String>();
    long starttime;

    public int getCount() {
        return count;
    }

    public producer( int n ,int Buffer) {

        N=n ;
        this.Buffer=Buffer;



    }
    public void run() {
        try {
            produce();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


    }

    public synchronized void produce() throws Exception{
        if(queue.size()==Buffer){
            wait();
        }
        starttime= System.currentTimeMillis();
        for(int num=2; num<=N;num++) {
            boolean flag = true;
            for (int i = 2; i < num; i++) {
                if (num % i == 0) {
                    flag = false;
                    break;
                }


            }
            if (flag == true) {


                queue.add(String.valueOf(num));

                count++;
                large_prime = num;

            }
        }
        long endTime = System.currentTimeMillis();


        JFrame f2=new JFrame("output");
        JLabel o1,o2,o3,o4 ,o5,o6 ;
        o1=new JLabel("The Largest Prime Number : ");
        o1.setBounds(30,20, 300,30);
        o2=new JLabel(String.valueOf(large_prime));
        o2.setBounds(310,20, 40,30);
        o3=new JLabel("# of element (Prime Number) generated : ");
        o3.setBounds(30,60, 300,30);
        o4=new JLabel(Integer.toString(count));
        o4.setBounds(310,60, 40,30);



        o5=new JLabel("Time elapsed  ");
        long ti = (endTime - starttime);
        String time =String.valueOf(ti)+ " ms" ;
        o5.setBounds(30,90, 300,30);
        o6=new JLabel(time);
        o6.setBounds(310,90, 200,30);
        f2.add(o1);f2.add(o2);f2.add(o3);f2.add(o4);
        f2.add(o5);f2.add(o6);
        f2.setSize(450,230);
        f2.setLayout(null);
        f2.setVisible(true);
        f2.getContentPane().setBackground(Color.lightGray);
    }



}
