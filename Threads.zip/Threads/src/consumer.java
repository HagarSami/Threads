import java.io.FileWriter;
import java.io.IOException;


public class consumer implements Runnable{

    String file;
    producer p ;


    public consumer(String filename,producer p ) {

        file=filename;
        this.p=p ;
    }
    @Override
    public void run() {
        try {
            consume();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
    public synchronized void consume() throws Exception{
        try {
            FileWriter myWriter = new FileWriter(file);
            if(p.queue.isEmpty()){
                System.out.println("Queue is Empty");
                throw new Exception();
            }
            while(!p.queue.isEmpty()) {

                String item = p.queue.poll();
                myWriter.write(item);
                myWriter.write(" , ");




            }
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
