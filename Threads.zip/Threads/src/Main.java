import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {



        JFrame f=new JFrame("Calculate ");
        JLabel l1,l2,l3;
        l1=new JLabel(" N ");
        l1.setBounds(40,20, 100,30);
        final JTextField size=new JTextField();
        size.setBounds(150,25, 150,20);
        l2=new JLabel(" buffer");
        l2.setBounds(40,50, 100,30);
        final JTextField buffer=new JTextField();
        buffer.setBounds(150,50,160,20);
        l3=new JLabel("File name ");
        l3.setBounds(40,70, 100,30);
        final JTextField file=new JTextField();
        file.setBounds(150,75, 160,20);
        JButton b=new JButton("Start Producer");
        b.setBounds(150,110,150,20);
        f.add(size);
        f.add(buffer);
        f.add(file);
        f.add(b);
        f.add(l1);
        f.add(l2);
        f.add(l3);
        f.setSize(600,550);
        f.setLayout(null);
        f.setVisible(true);
        f.getContentPane().setBackground(Color.lightGray);
        b.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                int buffer_size = Integer.parseInt(buffer.getText());
                int n = Integer.parseInt(size.getText());
                String fileName= file.getText();
                producer p=new producer(n,buffer_size);
                consumer c=new consumer(fileName,  p);
                new Thread(p).start();
                new Thread(c).start();











            }
        });

    }
}